#include <algorithm>
#include "Book.h"

void sortBooks(Book books[], int size) {
    std::sort(books, books + size);
}
